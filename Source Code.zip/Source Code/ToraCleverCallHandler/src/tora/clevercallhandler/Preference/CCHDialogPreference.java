package tora.clevercallhandler.Preference;

import android.content.Context;
import android.preference.DialogPreference;
import android.util.AttributeSet;

public class CCHDialogPreference extends DialogPreference {

	public CCHDialogPreference(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	public CCHDialogPreference(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
}
