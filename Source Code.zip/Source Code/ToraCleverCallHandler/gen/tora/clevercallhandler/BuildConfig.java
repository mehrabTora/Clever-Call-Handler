/** Automatically generated file. DO NOT MODIFY */
package tora.clevercallhandler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}